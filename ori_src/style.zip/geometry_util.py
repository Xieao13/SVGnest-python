# geometry_util.py

import math
from typing import List, Dict, Any, Optional, Union, Tuple
import pyclipper

class GeometryUtil:
    """几何工具类"""
    
    @staticmethod
    def almost_equal(a: float, b: float, tolerance: float = 0.001) -> bool:
        """判断两个浮点数是否近似相等"""
        return abs(a - b) < tolerance

    @staticmethod
    def within_distance(p1: Dict, p2: Dict, distance: float) -> bool:
        """判断两点是否在给定距离内"""
        dx = p1['x'] - p2['x']
        dy = p1['y'] - p2['y']
        return dx * dx + dy * dy <= distance * distance

    @staticmethod
    def degrees_to_radians(angle: float) -> float:
        """角度转弧度"""
        return angle * math.pi / 180

    @staticmethod
    def radians_to_degrees(angle: float) -> float:
        """弧度转角度"""
        return angle * 180 / math.pi

    @staticmethod
    def normalize_vector(v: Dict) -> Dict:
        """向量归一化"""
        length = math.sqrt(v['x'] * v['x'] + v['y'] * v['y'])
        if length == 0:
            return {'x': 0, 'y': 0}
        return {'x': v['x'] / length, 'y': v['y'] / length}

    @staticmethod
    def on_segment(A: Dict, B: Dict, p: Dict) -> bool:
        """判断点p是否在线段AB上"""
        # 检查点p是否在线段AB的边界框内
        if (p['x'] <= max(A['x'], B['x']) and p['x'] >= min(A['x'], B['x']) and
            p['y'] <= max(A['y'], B['y']) and p['y'] >= min(A['y'], B['y'])):
            
            # 检查点p是否在线段AB上
            cross_product = ((p['y'] - A['y']) * (B['x'] - A['x']) -
                           (p['x'] - A['x']) * (B['y'] - A['y']))
            
            return abs(cross_product) < 1e-10
            
        return False

    @staticmethod
    def line_intersect(A: Dict, B: Dict, E: Dict, F: Dict, infinite: bool = False) -> Optional[Dict]:
        """
        计算两条线段的交点
        infinite: 如果为True，则将线段视为无限延长的直线
        """
        # 线段AB的方向向量
        dxAB = B['x'] - A['x']
        dyAB = B['y'] - A['y']
        
        # 线段EF的方向向量
        dxEF = F['x'] - E['x']
        dyEF = F['y'] - E['y']
        
        # 计算行列式
        det = dxAB * dyEF - dyAB * dxEF
        
        if abs(det) < 1e-10:  # 平行或重合
            return None
            
        # 计算参数t和s
        t = ((E['x'] - A['x']) * dyEF - (E['y'] - A['y']) * dxEF) / det
        s = ((E['x'] - A['x']) * dyAB - (E['y'] - A['y']) * dxAB) / det
        
        # 如果不是无限延长线，检查参数是否在[0,1]范围内
        if not infinite and (t < 0 or t > 1 or s < 0 or s > 1):
            return None
            
        # 计算交点
        return {
            'x': A['x'] + t * dxAB,
            'y': A['y'] + t * dyAB
        }

    @staticmethod
    def polygon_area(polygon: List[Dict]) -> float:
        """计算多边形面积（正值表示逆时针，负值表示顺时针）"""
        area = 0
        j = len(polygon) - 1
        
        for i in range(len(polygon)):
            area += (polygon[j]['x'] + polygon[i]['x']) * (polygon[j]['y'] - polygon[i]['y'])
            j = i
            
        return area / 2

    @staticmethod
    def get_polygon_bounds(polygon: List[Dict]) -> Dict:
        """获取多边形的边界框"""
        if not polygon:
            return {'x': 0, 'y': 0, 'width': 0, 'height': 0}
            
        minx = maxx = polygon[0]['x']
        miny = maxy = polygon[0]['y']
        
        for p in polygon[1:]:
            minx = min(minx, p['x'])
            miny = min(miny, p['y'])
            maxx = max(maxx, p['x'])
            maxy = max(maxy, p['y'])
            
        return {
            'x': minx,
            'y': miny,
            'width': maxx - minx,
            'height': maxy - miny
        }

    @staticmethod
    def rotate_polygon(polygon: List[Dict], angle: float) -> List[Dict]:
        """旋转多边形"""
        rad = GeometryUtil.degrees_to_radians(angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        
        rotated = []
        for p in polygon:
            rotated.append({
                'x': p['x'] * cos_a - p['y'] * sin_a,
                'y': p['x'] * sin_a + p['y'] * cos_a
            })
            
        # 确保返回的是一个普通列表，而不是继承了输入多边形的类型
        return list(rotated)

    @staticmethod
    def no_fit_polygon(A: List[Dict], B: List[Dict], inside: bool = False, 
                      search_edges: bool = False) -> List[List[Dict]]:
        """
        计算两个多边形的NFP（No-Fit Polygon）
        A: 静态多边形
        B: 移动多边形
        inside: 是否计算内部NFP
        search_edges: 是否搜索边
        """
        if len(A) < 3 or len(B) < 3:
            return []

        A_area = GeometryUtil.polygon_area(A)
        B_area = GeometryUtil.polygon_area(B)

        if A_area < 0:
            A.reverse()
        if B_area < 0:
            B.reverse()

        # 计算参考点
        minA = GeometryUtil.get_polygon_bounds(A)
        minB = GeometryUtil.get_polygon_bounds(B)
        reference = {'x': minB['x'], 'y': minB['y']}

        # 初始化NFP
        nfp = []
        start_point = None

        # 找到有效的起始点
        if inside:
            # 内部NFP的情况
            for i, p1 in enumerate(A):
                for j, p2 in enumerate(B):
                    # 检查是否是有效的起始位置
                    valid = True
                    for k, p3 in enumerate(B):
                        if k != j:
                            p = {
                                'x': p1['x'] - p2['x'] + p3['x'],
                                'y': p1['y'] - p2['y'] + p3['y']
                            }
                            if not GeometryUtil.point_in_polygon(p, A):
                                valid = False
                                break
                    if valid:
                        start_point = {
                            'x': p1['x'] - p2['x'],
                            'y': p1['y'] - p2['y']
                        }
                        break
                if start_point:
                    break
        else:
            # 外部NFP的情况
            start_point = {
                'x': A[0]['x'] - reference['x'],
                'y': A[0]['y'] - reference['y']
            }

        if not start_point:
            return []

        # 计算NFP
        current = start_point.copy()
        nfp.append([current.copy()])
        
        while True:
            min_distance = float('inf')
            next_point = None
            touch_index = -1

            # 检查所有可能的下一个位置
            for i, p1 in enumerate(A):
                for j, p2 in enumerate(B):
                    cand = {
                        'x': p1['x'] - p2['x'],
                        'y': p1['y'] - p2['y']
                    }
                    
                    if (abs(cand['x'] - current['x']) < 0.0001 and 
                        abs(cand['y'] - current['y']) < 0.0001):
                        continue

                    # 计算距离
                    dist = (cand['x'] - current['x'])**2 + (cand['y'] - current['y'])**2
                    
                    if dist < min_distance:
                        valid = True
                        
                        # 验证新位置是否有效
                        for k, p3 in enumerate(B):
                            if k != j:
                                p = {
                                    'x': p1['x'] - p2['x'] + p3['x'],
                                    'y': p1['y'] - p2['y'] + p3['y']
                                }
                                if inside != GeometryUtil.point_in_polygon(p, A):
                                    valid = False
                                    break
                                    
                        if valid:
                            min_distance = dist
                            next_point = cand
                            touch_index = i

            if not next_point or touch_index < 0:
                break

            # 检查是否回到起点
            if (len(nfp[0]) > 2 and 
                abs(next_point['x'] - nfp[0][0]['x']) < 0.0001 and 
                abs(next_point['y'] - nfp[0][0]['y']) < 0.0001):
                break

            current = next_point
            nfp[0].append(current.copy())

            # 防止无限循环
            if len(nfp[0]) > 10 * (len(A) + len(B)):
                break

        return nfp

    @staticmethod
    def point_in_polygon(point: Dict, polygon: List[Dict]) -> bool:
        """判断点是否在多边形内部"""
        if not polygon:
            return False
            
        inside = False
        j = len(polygon) - 1
        
        for i in range(len(polygon)):
            if (((polygon[i]['y'] > point['y']) != (polygon[j]['y'] > point['y'])) and
                (point['x'] < (polygon[j]['x'] - polygon[i]['x']) * 
                 (point['y'] - polygon[i]['y']) / (polygon[j]['y'] - polygon[i]['y']) + 
                 polygon[i]['x'])):
                inside = not inside
            j = i
            
        return inside

    class QuadraticBezier:
        """二次贝塞尔曲线工具"""
        
        @staticmethod
        def linearize(p0: Dict, p2: Dict, p1: Dict, tolerance: float) -> List[Dict]:
            """将二次贝塞尔曲线线性化"""
            points = [p0]
            GeometryUtil.QuadraticBezier._recursive_linearize(
                p0, p2, p1, tolerance, points
            )
            points.append(p2)
            return points

        @staticmethod
        def _recursive_linearize(p0: Dict, p2: Dict, p1: Dict, 
                               tolerance: float, points: List[Dict]):
            """递归线性化二次贝塞尔曲线"""
            # 计算曲线中点
            mid = {
                'x': (p0['x'] + 2 * p1['x'] + p2['x']) / 4,
                'y': (p0['y'] + 2 * p1['y'] + p2['y']) / 4
            }
            
            # 计算直线中点
            line_mid = {
                'x': (p0['x'] + p2['x']) / 2,
                'y': (p0['y'] + p2['y']) / 2
            }
            
            # 计算误差
            dx = mid['x'] - line_mid['x']
            dy = mid['y'] - line_mid['y']
            error = dx * dx + dy * dy
            
            if error <= tolerance:
                points.append(mid)
            else:
                # 分割曲线并递归
                p0_1 = {
                    'x': (p0['x'] + p1['x']) / 2,
                    'y': (p0['y'] + p1['y']) / 2
                }
                p1_2 = {
                    'x': (p1['x'] + p2['x']) / 2,
                    'y': (p1['y'] + p2['y']) / 2
                }
                
                GeometryUtil.QuadraticBezier._recursive_linearize(
                    p0, mid, p0_1, tolerance, points
                )
                GeometryUtil.QuadraticBezier._recursive_linearize(
                    mid, p2, p1_2, tolerance, points
                )

    class CubicBezier:
        """三次贝塞尔曲线工具"""
        
        @staticmethod
        def linearize(p0: Dict, p3: Dict, p1: Dict, p2: Dict, 
                     tolerance: float) -> List[Dict]:
            """将三次贝塞尔曲线线性化"""
            points = [p0]
            GeometryUtil.CubicBezier._recursive_linearize(
                p0, p3, p1, p2, tolerance, points
            )
            points.append(p3)
            return points

        @staticmethod
        def _recursive_linearize(p0: Dict, p3: Dict, p1: Dict, p2: Dict, 
                               tolerance: float, points: List[Dict]):
            """递归线性化三次贝塞尔曲线"""
            # 计算曲线中点
            mid = {
                'x': (p0['x'] + 3 * (p1['x'] + p2['x']) + p3['x']) / 8,
                'y': (p0['y'] + 3 * (p1['y'] + p2['y']) + p3['y']) / 8
            }
            
            # 计算直线中点
            line_mid = {
                'x': (p0['x'] + p3['x']) / 2,
                'y': (p0['y'] + p3['y']) / 2
            }
            
            # 计算误差
            dx = mid['x'] - line_mid['x']
            dy = mid['y'] - line_mid['y']
            error = dx * dx + dy * dy
            
            if error <= tolerance:
                points.append(mid)
            else:
                # 分割曲线并递归
                p0_1 = {
                    'x': (p0['x'] + p1['x']) / 2,
                    'y': (p0['y'] + p1['y']) / 2
                }
                p1_2 = {
                    'x': (p1['x'] + p2['x']) / 2,
                    'y': (p1['y'] + p2['y']) / 2
                }
                p2_3 = {
                    'x': (p2['x'] + p3['x']) / 2,
                    'y': (p2['y'] + p3['y']) / 2
                }
                p01_12 = {
                    'x': (p0_1['x'] + p1_2['x']) / 2,
                    'y': (p0_1['y'] + p1_2['y']) / 2
                }
                p12_23 = {
                    'x': (p1_2['x'] + p2_3['x']) / 2,
                    'y': (p1_2['y'] + p2_3['y']) / 2
                }
                
                GeometryUtil.CubicBezier._recursive_linearize(
                    p0, mid, p0_1, p01_12, tolerance, points
                )
                GeometryUtil.CubicBezier._recursive_linearize(
                    mid, p3, p12_23, p2_3, tolerance, points
                )

    class Arc:
        """圆弧工具"""
        
        @staticmethod
        def linearize(start: Dict, end: Dict, rx: float, ry: float, 
                     angle: float, large_arc: bool, sweep: bool, 
                     tolerance: float) -> List[Dict]:
            """将圆弧线性化"""
            # 将角度转换为弧度
            angle_rad = GeometryUtil.degrees_to_radians(angle)
            cos_angle = math.cos(angle_rad)
            sin_angle = math.sin(angle_rad)
            
            # 计算中心点
            dx = (start['x'] - end['x']) / 2
            dy = (start['y'] - end['y']) / 2
            
            x1 = cos_angle * dx + sin_angle * dy
            y1 = -sin_angle * dx + cos_angle * dy
            
            # 确保半径足够大
            rx = abs(rx)
            ry = abs(ry)
            x1_sq = x1 * x1
            y1_sq = y1 * y1
            rx_sq = rx * rx
            ry_sq = ry * ry
            
            lambda_sq = x1_sq / rx_sq + y1_sq / ry_sq
            if lambda_sq > 1:
                lambda_sqrt = math.sqrt(lambda_sq)
                rx *= lambda_sqrt
                ry *= lambda_sqrt
                rx_sq = rx * rx
                ry_sq = ry * ry
                
            # 计算中心点
            c_sign = -1 if large_arc == sweep else 1
            c_term = c_sign * math.sqrt(
                max(0, (rx_sq * ry_sq - rx_sq * y1_sq - ry_sq * x1_sq) / 
                    (rx_sq * y1_sq + ry_sq * x1_sq))
            )
            
            cx1 = c_term * rx * y1 / ry
            cy1 = -c_term * ry * x1 / rx
            
            cx = cos_angle * cx1 - sin_angle * cy1 + (start['x'] + end['x']) / 2
            cy = sin_angle * cx1 + cos_angle * cy1 + (start['y'] + end['y']) / 2
            
            # 计算角度
            ux = (x1 - cx1) / rx
            uy = (y1 - cy1) / ry
            vx = (-x1 - cx1) / rx
            vy = (-y1 - cy1) / ry
            
            start_angle = math.atan2(uy, ux)
            delta_angle = math.atan2(vy * ux - vx * uy, vx * ux + vy * uy)
            
            if not sweep and delta_angle > 0:
                delta_angle -= 2 * math.pi
            elif sweep and delta_angle < 0:
                delta_angle += 2 * math.pi
                
            # 线性化
            num_segments = max(
                math.ceil(abs(delta_angle) / math.acos(1 - tolerance / max(rx, ry))),
                4
            )
            
            points = [start]
            for i in range(1, num_segments):
                t = i / num_segments
                angle = start_angle + t * delta_angle
                
                x = cos_angle * rx * math.cos(angle) - sin_angle * ry * math.sin(angle) + cx
                y = sin_angle * rx * math.cos(angle) + cos_angle * ry * math.sin(angle) + cy
                
                points.append({'x': x, 'y': y})
                
            points.append(end)
            return points