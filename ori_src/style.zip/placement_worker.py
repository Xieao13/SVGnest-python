# placement_worker.py

import math
from typing import List, Dict, Any, Optional, Union
import pyclipper
from geometry_util import GeometryUtil

def to_clipper_coordinates(polygon: List[Dict]) -> List[tuple]:
    """将普通坐标转换为Clipper坐标(元组格式)"""
    return [(int(p['x']), int(p['y'])) for p in polygon]

def to_nest_coordinates(polygon: List[tuple], scale: float) -> List[Dict]:
    """将Clipper坐标转回普通坐标"""
    return [{'x': p[0]/scale, 'y': p[1]/scale} for p in polygon]

def rotate_polygon(polygon: List[Dict], degrees: float) -> List[Dict]:
    """旋转多边形"""
    rotated = []
    angle = degrees * math.pi / 180
    
    for p in polygon:
        x = p['x']
        y = p['y']
        x1 = x * math.cos(angle) - y * math.sin(angle)
        y1 = x * math.sin(angle) + y * math.cos(angle)
        rotated.append({'x': x1, 'y': y1})
        
    if hasattr(polygon, 'children') and polygon.children:
        rotated.children = []
        for child in polygon.children:
            rotated.children.append(rotate_polygon(child, degrees))
            
    return rotated

class PlacementWorker:
    def __init__(self, bin_polygon: List[Dict], paths: List[Dict], 
                 ids: List[int], rotations: List[float], 
                 config: Dict, nfp_cache: Optional[Dict] = None):
        """初始化放置工作器"""
        self.bin_polygon = bin_polygon
        self.paths = paths
        self.ids = ids
        self.rotations = rotations
        self.config = config
        self.nfp_cache = nfp_cache or {}

    def place_paths(self, paths: List[Dict]) -> Dict:
        """放置路径并返回放置结果"""
        if not self.bin_polygon:
            return None

        # 按给定角度旋转路径
        rotated = []
        for i, path in enumerate(paths):
            # 检查rotation是否存在
            if hasattr(path, 'rotation'):
                rotation = path.rotation
            else:
                # 从rotations列表中获取
                rotation = self.rotations[i] if i < len(self.rotations) else 0
                
            r = rotate_polygon(path, rotation)
            
            # 使用自定义列表以便添加属性
            CustomList = type('CustomList', (list,), {})
            if not isinstance(r, CustomList):
                r = CustomList(r)
                
            r.rotation = rotation
            
            if hasattr(path, 'source'):
                r.source = path.source
            else:
                r.source = i
                
            if hasattr(path, 'id'):
                r.id = path.id
            else:
                r.id = i
                
            rotated.append(r)

        paths = rotated
        all_placements = []
        fitness = 0
        bin_area = abs(GeometryUtil.polygon_area(self.bin_polygon))

        while paths:
            placed = []
            placements = []
            fitness += 1  # 每打开一个新bin增加1(较低的适应度更好)
            min_width = None  # 初始化min_width变量

            for path in paths:
                # 内部NFP
                key = str({
                    'A': -1,
                    'B': path.id,
                    'inside': True,
                    'Arotation': 0,
                    'Brotation': path.rotation
                })
                bin_nfp = self.nfp_cache.get(key)

                # 部件不可放置，跳过
                if not bin_nfp or not bin_nfp:
                    continue

                # 确保所有必要的NFP存在
                error = False
                for placed_path in placed:
                    key = str({
                        'A': placed_path.id,
                        'B': path.id,
                        'inside': False,
                        'Arotation': placed_path.rotation,
                        'Brotation': path.rotation
                    })
                    nfp = self.nfp_cache.get(key)

                    if not nfp:
                        error = True
                        break

                # 部件不可放置，跳过
                if error:
                    continue

                position = None
                if not placed:
                    # 第一次放置，放在左侧
                    for nfp_part in bin_nfp:
                        for point in nfp_part:
                            start_x = 0
                            if isinstance(path[0], dict) and 'x' in path[0]:
                                start_x = path[0]['x']
                            elif hasattr(path, 'get') and path.get(0, {}).get('x') is not None:
                                start_x = path.get(0, {}).get('x', 0)
                            elif hasattr(path, 'x'):
                                start_x = path.x
                                
                            if position is None or point['x'] - start_x < (position.x if hasattr(position, 'x') else position['x'] if isinstance(position, dict) else 0):
                                position = CustomList()
                                position.x = point['x'] - start_x
                                position.y = point['y'] - (path[0]['y'] if isinstance(path[0], dict) and 'y' in path[0] else 
                                                        path.get(0, {}).get('y', 0) if hasattr(path, 'get') else 
                                                        path.y if hasattr(path, 'y') else 0)
                                position.id = path.id
                                position.rotation = path.rotation

                    placements.append(position)
                    placed.append(path)
                    continue

                # 使用pyclipper进行布尔运算
                pc = pyclipper.Pyclipper()
                
                # 转换bin_nfp为clipper格式
                clipper_bin_nfp = []
                for nfp_part in bin_nfp:
                    clipper_bin_nfp.append(to_clipper_coordinates(nfp_part))

                # 缩放坐标
                scale = self.config['clipperScale']
                scaled_bin_nfp = pyclipper.scale_to_clipper(clipper_bin_nfp, scale)

                combined_nfp = []
                for placed_path in placed:
                    key = str({
                        'A': placed_path.id,
                        'B': path.id,
                        'inside': False,
                        'Arotation': placed_path.rotation,
                        'Brotation': path.rotation
                    })
                    nfp = self.nfp_cache.get(key)

                    if not nfp:
                        continue

                    for nfp_part in nfp:
                        # 转换并平移NFP
                        clone = to_clipper_coordinates(nfp_part)
                        placement = placements[placed.index(placed_path)]
                        translated = [(p[0] + int(placement.x * scale), 
                                    p[1] + int(placement.y * scale)) 
                                   for p in clone]
                        
                        # 清理并检查面积
                        cleaned = pyclipper.CleanPolygon(translated, 
                                                        0.0001 * scale)
                        if cleaned:
                            area = abs(pyclipper.Area(cleaned))
                            if (len(cleaned) > 2 and 
                                area > 0.1 * scale * scale):
                                pc.AddPath(cleaned, 
                                         pyclipper.PT_SUBJECT, 
                                         True)

                try:
                    # 执行布尔并运算
                    combined_nfp = pc.Execute(pyclipper.CT_UNION, 
                                            pyclipper.PFT_NONZERO, 
                                            pyclipper.PFT_NONZERO)
                except pyclipper.ClipperException:
                    continue

                # 与bin多边形求差
                pc = pyclipper.Pyclipper()
                pc.AddPaths(combined_nfp, pyclipper.PT_CLIP, True)
                pc.AddPaths(scaled_bin_nfp, pyclipper.PT_SUBJECT, True)

                try:
                    final_nfp = pc.Execute(pyclipper.CT_DIFFERENCE, 
                                         pyclipper.PFT_NONZERO, 
                                         pyclipper.PFT_NONZERO)
                except pyclipper.ClipperException:
                    continue

                # 清理结果
                final_nfp = [pyclipper.CleanPolygon(p, 0.0001 * scale) 
                            for p in final_nfp]
                final_nfp = [p for p in final_nfp if p]  # 移除空结果

                # 清理面积太小的多边形
                final_nfp = [p for p in final_nfp 
                            if len(p) >= 3 and 
                            abs(pyclipper.Area(p)) >= 0.1 * scale * scale]

                if not final_nfp:
                    continue

                # 转回普通坐标
                final_nfp = [pyclipper.scale_from_clipper(p, scale) 
                            for p in final_nfp]
                final_nfp = [to_nest_coordinates(p, 1) for p in final_nfp]

                # 选择产生最小边界框的放置位置
                min_area = None
                min_x = None

                for nfp_part in final_nfp:
                    if abs(GeometryUtil.polygon_area(nfp_part)) < 2:
                        continue

                    for point in nfp_part:
                        all_points = []
                        
                        # 收集所有已放置部件的点
                        for placed_path, placement in zip(placed, placements):
                            for p in placed_path:
                                p_x = 0
                                p_y = 0
                                if isinstance(p, dict) and 'x' in p and 'y' in p:
                                    p_x = p['x']
                                    p_y = p['y']
                                elif hasattr(p, 'get'):
                                    p_x = p.get('x', 0)
                                    p_y = p.get('y', 0)
                                elif hasattr(p, 'x') and hasattr(p, 'y'):
                                    p_x = p.x
                                    p_y = p.y
                                    
                                all_points.append({
                                    'x': p_x + placement.x,
                                    'y': p_y + placement.y
                                })

                        shift_vector = CustomList()
                        start_x = 0
                        start_y = 0
                        if isinstance(path[0], dict) and 'x' in path[0]:
                            start_x = path[0]['x']
                            start_y = path[0]['y']
                        elif hasattr(path, 'get') and path.get(0, {}).get('x') is not None:
                            start_x = path.get(0, {}).get('x', 0)
                            start_y = path.get(0, {}).get('y', 0)
                        elif hasattr(path, 'x'):
                            start_x = path.x
                            start_y = path.y
                            
                        shift_vector.x = point['x'] - start_x
                        shift_vector.y = point['y'] - start_y
                        shift_vector.id = path.id
                        shift_vector.rotation = path.rotation
                        shift_vector.nfp = combined_nfp

                        # 添加当前部件的点
                        for p in path:
                            p_x = 0
                            p_y = 0
                            if isinstance(p, dict) and 'x' in p and 'y' in p:
                                p_x = p['x']
                                p_y = p['y']
                            elif hasattr(p, 'get'):
                                p_x = p.get('x', 0)
                                p_y = p.get('y', 0)
                            elif hasattr(p, 'x') and hasattr(p, 'y'):
                                p_x = p.x
                                p_y = p.y
                                
                            all_points.append({
                                'x': p_x + shift_vector.x,
                                'y': p_y + shift_vector.y
                            })

                        rect_bounds = GeometryUtil.get_polygon_bounds(all_points)
                        
                        # 权重更偏向宽度，以帮助在重力方向上压缩
                        area = rect_bounds['width'] * 2 + rect_bounds['height']

                        if (min_area is None or 
                            area < min_area or 
                            (GeometryUtil.almost_equal(min_area, area) and 
                             (min_x is None or shift_vector.x < min_x))):
                            min_area = area
                            min_width = rect_bounds['width']
                            position = shift_vector
                            min_x = shift_vector.x

                if position:
                    placed.append(path)
                    placements.append(position)

            if min_width:
                fitness += min_width / bin_area

            # 移除已放置的部件
            for placed_path in placed:
                paths.remove(placed_path)

            if placements:
                all_placements.append(placements)
            else:
                break  # 出错了

        # 有部件无法放置
        fitness += 2 * len(paths)

        return {
            'placements': all_placements,
            'fitness': fitness,
            'paths': paths,
            'area': bin_area
        }