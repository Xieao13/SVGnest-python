# genetic_algorithm.py

import math
import random
from typing import List, Dict, Any, Optional
from geometry_util import GeometryUtil

class GeneticAlgorithm:
    """遗传算法类，用于优化零件布局"""
    
    def __init__(self, adam: List, bin_polygon: List, config: Dict):
        """
        初始化遗传算法
        adam: 初始个体
        bin_polygon: 容器多边形
        config: 配置参数
        """
        self.config = config or {
            'populationSize': 10,
            'mutationRate': 10,
            'rotations': 4
        }
        self.bin_bounds = GeometryUtil.get_polygon_bounds(bin_polygon)
        
        # 初始化种群
        # 为每个零件分配随机角度
        angles = [self.random_angle(part) for part in adam]
        
        self.population = [{
            'placement': adam,
            'rotation': angles
        }]
        
        # 生成初始种群
        while len(self.population) < config['populationSize']:
            mutant = self.mutate(self.population[0])
            self.population.append(mutant)

    def random_angle(self, part: List) -> float:
        """为零件选择随机旋转角度"""
        # 生成可能的角度列表
        angle_list = [i * (360 / max(self.config['rotations'], 1)) 
                     for i in range(max(self.config['rotations'], 1))]
        
        # 随机打乱角度列表
        random.shuffle(angle_list)
        
        # 尝试每个角度，找到合适的
        for angle in angle_list:
            rotated_part = GeometryUtil.rotate_polygon(part, angle)
            bounds = GeometryUtil.get_polygon_bounds(rotated_part)
            
            # 如果旋转后的零件能放入容器，使用这个角度
            if (bounds['width'] < self.bin_bounds['width'] and 
                bounds['height'] < self.bin_bounds['height']):
                return angle
                
        return 0

    def mutate(self, individual: Dict) -> Dict:
        """变异操作"""
        clone = {
            'placement': individual['placement'][:],
            'rotation': individual['rotation'][:]
        }
        
        # 对每个零件
        for i in range(len(clone['placement'])):
            # 有一定概率交换位置
            if random.random() < 0.01 * self.config['mutationRate']:
                j = i + 1
                if j < len(clone['placement']):
                    # 交换位置
                    clone['placement'][i], clone['placement'][j] = \
                        clone['placement'][j], clone['placement'][i]
                    
            # 有一定概率改变旋转角度
            if random.random() < 0.01 * self.config['mutationRate']:
                clone['rotation'][i] = self.random_angle(clone['placement'][i])
                
        return clone

    def mate(self, male: Dict, female: Dict) -> List[Dict]:
        """交配操作"""
        # 选择交叉点
        cutpoint = round(min(max(random.random(), 0.1), 0.9) * 
                        (len(male['placement']) - 1))
        
        # 创建子代1
        gene1 = male['placement'][:cutpoint]
        rot1 = male['rotation'][:cutpoint]
        
        # 创建子代2
        gene2 = female['placement'][:cutpoint]
        rot2 = female['rotation'][:cutpoint]
        
        # 补充剩余基因
        for i in range(len(female['placement'])):
            if not self._contains(gene1, female['placement'][i]['id']):
                gene1.append(female['placement'][i])
                rot1.append(female['rotation'][i])
                
        for i in range(len(male['placement'])):
            if not self._contains(gene2, male['placement'][i]['id']):
                gene2.append(male['placement'][i])
                rot2.append(male['rotation'][i])
                
        return [
            {'placement': gene1, 'rotation': rot1},
            {'placement': gene2, 'rotation': rot2}
        ]

    def _contains(self, gene: List, id: int) -> bool:
        """检查基因序列是否包含指定ID的零件"""
        return any(part['id'] == id for part in gene)

    def generation(self):
        """生成新一代种群"""
        # 按适应度排序
        self.population.sort(key=lambda x: x.get('fitness', float('inf')))
        
        # 保留最优个体
        new_population = [self.population[0]]
        
        # 生成新的种群
        while len(new_population) < len(self.population):
            # 选择父母
            male = self._random_weighted_individual()
            female = self._random_weighted_individual(male)
            
            # 生成子代
            children = self.mate(male, female)
            
            # 变异并添加到新种群
            new_population.append(self.mutate(children[0]))
            
            if len(new_population) < len(self.population):
                new_population.append(self.mutate(children[1]))
                
        self.population = new_population

    def _random_weighted_individual(self, exclude: Optional[Dict] = None) -> Dict:
        """
        从种群中随机选择个体，前面的个体（适应度更好）有更高的选择概率
        exclude: 要排除的个体
        """
        pop = self.population[:]
        if exclude and exclude in pop:
            pop.remove(exclude)
            
        rand = random.random()
        
        # 计算权重
        weight = 1 / len(pop)
        lower = 0
        upper = weight
        
        for i, individual in enumerate(pop):
            if rand > lower and rand < upper:
                return individual
            lower = upper
            upper += 2 * weight * ((len(pop) - i) / len(pop))
            
        return pop[0]